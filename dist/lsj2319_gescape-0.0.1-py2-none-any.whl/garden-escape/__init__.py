# __init__.py

# Version of the garden-escape package
__version__ = "1.0.0"