# Garden Escape

Garden Escape was my final beginner project for Code in Place 2020. 
It is a Gardening simulation game using tKinter for the GUI. 
## How to Play
Use the mouse to move the gardener character. 
Press spacebar or doubleclick to plant flowers or shrubs at the current location of the gardener.

## Libraries
This game uses tkinter to render a GUI window so you can play the game.
PIL is also used to help with image handling. 

